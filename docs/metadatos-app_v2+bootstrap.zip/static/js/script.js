// Tu código JavaScript aquí (si es necesario)
console.log("Script cargado!");
